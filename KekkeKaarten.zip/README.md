# KekkeKaarten
PAD project


Code Conventions:

Full code in English<br />
HvA code conventions<br />
Make sure your variables are private if they can be<br />

Comment functions accordingly:
<p>
// Summary:<br />
// 	&emsp;[Summary. Lorem Ipsum Dolor Sit Amet]<br />
// 		Parameters:<br />
// &emsp;param:<br />
// 	&emsp;&emsp;This is a parameter<br />
//<br />
// Returns:<br />
// 	&emsp;[return value]<br />
</p>

<hr />

Drive link: https://drive.google.com/drive/folders/1a4Bmu0oLdKU2XzOOgplC9ktB1Hb6-L9f?usp=sharing

<hr />

Trello: https://trello.com/b/80DLVVJj/sprint-3
