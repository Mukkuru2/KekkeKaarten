﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace KekkeKaarten.GameObjects.MapObjects
{
    class Floor : MapObject
    {

        public Floor(String asset, Vector2 position) : base(asset)
        {
            this.position = position;
        }
    }
}
